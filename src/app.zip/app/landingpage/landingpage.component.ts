import { Component } from '@angular/core';

@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.scss']
})
export class LandingpageComponent {

  a:boolean=false;
  b:boolean=true;
  c:boolean=true;

  staus:string="inrange";
}


