import { Component } from '@angular/core';

@Component({
  selector: 'app-myhome',
  templateUrl: './myhome.component.html',
  styleUrls: ['./myhome.component.scss']
})
export class MyhomeComponent {
  abc:string="kumar";
  name="this is user name";
}
